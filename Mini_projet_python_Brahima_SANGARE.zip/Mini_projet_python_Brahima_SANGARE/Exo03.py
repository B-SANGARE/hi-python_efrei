import random
def jouer(c):
   if c == 1:
      return "pierre"
   elif c == 2:
      return "papier"
   elif c==3 :
      return "ciseaux"
   else:
      return "Choix invalide!"
print("Jeux Pierre Papier Ciseaux avec l'ordinateur")
score_user = 0
score_ordinateur = 0
while True:
     user= int(input("Entrez votre choix : "))
     x=random.randint(1,3)
     print("Choix de l'ordinateur : ", jouer(x))
     print("Choix de l'utilisateur : ", jouer(user))
if (x==1 and user==2) or (x==2 and user==3) or (x==3 and user==1):
    score_user+= 1
elif (x==1 and user==3) or (x==2 and user==1) or (x==3 and user==2):
     score_ordinateur+=1
if (score_user == 3) or (score_ordinateur==3):
    print("joueur {} ordinateur {}".format(score_user, score_ordinateur))
    print("Fin du match !")

print("joueur {} ordinateur {}".format(score_user, score_ordinateur))
print("Fin Jeux.")