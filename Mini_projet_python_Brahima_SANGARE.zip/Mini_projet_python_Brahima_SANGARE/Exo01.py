from flatten_json import flatten
import csv

#json 
json_data = {
    "groupe": "Pearl Jam",
    "titre_album": "Ten",
    "annee": 1991,
    "genre": "Alternative",
    "titres": {
        "1": "Once",
        "2": "Even Flow",
        "3": "Alive",
        "4": "Why Go",
        "5": "Black",
        "6": "Jeremy",
        "7": "Oceans",
        "8": "Porch",
        "9": "Garden",
        "10": "Deep",
        "11": "Release"
    }
}

#flatten json
json_flatten_data = flatten(json_data) 

#fichier csv
file = open("18-data.csv", "w")
all_keys = []
for element in json_flatten_data:
    all_keys.append(element)
writter = csv.DictWriter(file, all_keys)
writter.writeheader()
writter.writerow(json_flatten_data)
file.close()