import json

#lecture
with open ("data.json","r") as read_file:
    data = json.load(read_file)
    
#affichage
for cle in data:
    print("cle: ", cle, " valeur: ", data[cle])