import random 

a= random.randint(1,6)

b= random.randint(1,6)

somme= a+b
print(a)
print(b)
print(somme)